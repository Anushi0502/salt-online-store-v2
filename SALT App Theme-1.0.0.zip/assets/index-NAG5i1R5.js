const __vite__mapDeps=(i,m=__vite__mapDeps,d=(m.f||(m.f=["assets/web-CJJ3fygS.js","assets/index-CV4Cquht.js"])))=>i.map(i=>d[i]);
import{as as e}from"./index-DkOfGw50.js";import{r as p}from"./index-CV4Cquht.js";const i=p("App",{web:()=>e(()=>import("./web-CJJ3fygS.js"),__vite__mapDeps([0,1])).then(r=>new r.AppWeb)});export{i as App};
